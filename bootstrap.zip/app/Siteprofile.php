<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siteprofile extends Model
{
    //
}
